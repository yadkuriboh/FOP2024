# 
# hello.py: Print out greetings in various languagues 
#

print("Hello")
print("Vanacum")
print("G'day")
print("Bula")
print("Kia ora")
print("Bonjour")
print("Namaste")