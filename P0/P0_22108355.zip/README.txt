## Synopsis 
Practical 0 of Fundamentals of Programming COMP1005/5005

## Contents 
README - readme file for Practical 0 
hello.py - Prints out hello in different languages 

## Dependencies 
none

## Version information 
22/06/2025 - initial version of Practical 0 programs